ghdl -a RTLComponents.vhdl LongDivision.vhdl GCDCalculator.vhdl GCDStream.vhdl Testbench.vhdl
ghdl -m Testbench

GCD Stream calculator
-------------------

Calculates and outputs the GCD of 8 numbers given as a stream.

For EE 214 assignment.

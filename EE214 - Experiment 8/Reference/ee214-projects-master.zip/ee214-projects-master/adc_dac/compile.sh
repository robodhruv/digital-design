ghdl -a components.vhdl adc.vhdl TestADC.vhdl sram.vhdl TestSRAM.vhdl ccu.vhdl
ghdl -m TestADC
ghdl -m TestSRAM
